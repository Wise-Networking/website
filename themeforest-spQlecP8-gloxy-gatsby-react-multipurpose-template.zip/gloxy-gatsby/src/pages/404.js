import React from 'react'
import Layout from '../components/App/Layout'

const CustomError = () => {
    return (
        <Layout>
            <h1>Not Found!</h1>
        </Layout>
    )
}

export default CustomError
